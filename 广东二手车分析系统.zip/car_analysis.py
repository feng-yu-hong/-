import pandas  # 导入数据统计模块

data = pandas.read_csv(r'data/data.csv',encoding='gb18030')    # 读取csv数据文件
del data['Unnamed: 0']                             # 将索引列删除
data.dropna(axis=0, how='any', inplace=True)       # 删除data数据中的所有空值
# print(data)

# 对二手车的  原价  进行数据预处理
data['现价'] = data['现价'].astype(float)                          # 将二手车现价转换为浮点类型

# 对二手车的  原价  进行数据预处理
data['原价'] = data['原价'].map(lambda d: d.replace('万', ''))     # 将原价 “万 ”去掉
# print(data['原价'])
data['原价'] = data['原价'].astype(float)                          # 将二手车原价转换为浮点类型

# 对二手车的  里程  进行数据预处理
data['里程'] = data['里程'].map(lambda d: d.replace('万公里', ''))     # 将里程“万公里”去掉
# print(data['里程'])
data['里程'] = data['里程'].astype(float)                             # 将车辆里程转换为浮点类型


# 数据分析
#  1.获取广东各市二手车均价分析
def get_average_price():
    group = data.groupby('区域')                # 将二手车区域分组
    average_price_group = group['现价'].mean()  # 计算每个市区域内二手车的均价
    region = average_price_group.index         # 区域
    average_price = average_price_group.values.astype(int)   # 区域对应的均价
    return region, average_price                             # 返回区域与对应的均价

#  2.获取广东各市二手车数量比例
def get_car_number():
    group_number = data.groupby('区域').size()   # 二手车的区域分组数量
    region = group_number.index                 # 区域
    numbers = group_number.values               # 获取每个市区内二手车出售的数量
    percentage = numbers / numbers.sum() * 100  # 计算每个市二手车数量的百分比
    return region, percentage                   # 返回百分比

#  3.获取广东各市二手车市场过户情况对比
def get_renovation():
    group_renovation = data.groupby('过户').size()  # 将二手车过户类型分组并统计数量
    type = group_renovation.index                  # 二手车过户分类的类型
    number = group_renovation.values               # 二手车过户分类的类型所对应的数量
    return type, number                            # 返回二手车过户分类与对应的数量

#  4.获取广东各市二手车市场过户次数类型与其均价分析
def get_car_type():
    car_type_number = data.groupby('过户').size()                  # 获取过户分组数量
    sort_values = car_type_number.sort_values(ascending=False)    # 将过户类型分组数量进行降序
    top_five = sort_values.head(10)                               # 提取前 10 组户型数据
    car_type_mean = data.groupby('过户')['现价'].mean()            # 计算每个过户类型分组的均价
    type = car_type_mean[top_five.index].index                    # 过户类型
    price = car_type_mean[top_five.index].values                  # 过户类型对应的均价
    return type, price.astype(int)                                # 返回过户类型与对应的数量
