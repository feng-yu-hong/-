import requests    # 发送请求
import parsel      # 解析数据模块
import csv         # 内置保存模块

# 获取 汽车之家 条车辆数据

# 伪装 请求头 Response Headers
headers = {
    # 浏览器基本信息
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36',
    # 用户基本信息
    'Cookie': 'fvlid=1653202539712Ldp5RyulY8gZ; sessionid=cb45a361-e423-41b2-8344-5c127626f27e; area=440112; che_sessionid=3F278FC0-A60B-471B-8A52-DCE8D4E92E69%7C%7C2022-05-22+14%3A55%3A45.705%7C%7C0; sessionip=120.85.104.181; sessionvisit=95e46272-b05d-4856-bd23-715569007900; sessionvisitInfo=cb45a361-e423-41b2-8344-5c127626f27e|www.autohome.com.cn|110965; Hm_lvt_d381ec2f88158113b9b76f14c497ed48=1653202542,1653313059,1653370589; che_sessionvid=52F8EAA7-57F3-4FBA-BCA6-9EFAAAC24DDF; listuserarea=440000; UsedCarBrowseHistory=0%3A43199062; userarea=440000; ahpvno=13; showNum=15; ahuuid=92B597B5-958D-4C62-8775-136A9CAF6753; Hm_lpvt_d381ec2f88158113b9b76f14c497ed48=1653371068; v_no=15; visit_info_ad=3F278FC0-A60B-471B-8A52-DCE8D4E92E69||52F8EAA7-57F3-4FBA-BCA6-9EFAAAC24DDF||-1||-1||15; che_ref=www.autohome.com.cn%7C0%7C110965%7C0%7C2022-05-24+13%3A44%3A30.189%7C2022-05-23+21%3A37%3A44.905; sessionuid=cb45a361-e423-41b2-8344-5c127626f27e'
}

# 访问网址
url = 'https://www.che168.com/guangdong/a0_0msdgscncgpi1ltocsp1exx0/'
# 1. 发送请求（访问网站）
response = requests.get(url=url,headers=headers)

# 2. 获取数据 网页源代码
html_data = response.text

# 3. 解析数据（网页构造 ， css样式选择器）
selector = parsel.Selector(html_data)       # 解析工具
lis = selector.css('.viewlist_ul li')       # 数据容器  列表
for li in lis:
    # 车辆名称
    card_name = li.css('.card-name::text').get()
    # 车辆信息
    cards_unit = li.css('.cards-unit::text').get()
    # 车辆实际价格
    price = li.css('.pirce em::text').get()
    if price == None or price == "":
        price = li.css('.pirce::text').get()
    # 车辆原价
    cards_price = li.css('.cards-price-box s::text').get()
    # 车辆状态
    tags = li.css('.tags i::text').get()

    # 4. 数据保存
    with open('data.csv', mode='a',encoding='utf-8',newline='') as f:
        csv_writer = csv.writer(f)
        csv_writer.writerow([card_name, cards_unit, price, cards_price, tags])








